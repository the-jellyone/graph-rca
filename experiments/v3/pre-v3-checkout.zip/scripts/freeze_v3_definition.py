"""Preserve the pre-v3 checkout and declare the experiment without Docker writes."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

from rca_investigation.contracts import digest
from rca_investigation.dataset import atomic_json
from rca_investigation.train import runtime_hash


def main():
    root = Path.cwd()
    destination = root / 'experiments/v3'
    declaration_path = destination / 'experiment-declaration.json'
    if declaration_path.exists():
        raise ValueError('definition already frozen; validate it instead of overwriting')
    destination.mkdir(parents=True, exist_ok=True)
    files = [p for folder in ('src', 'tests', 'scripts', 'configs', 'docs')
             for p in (root / folder).rglob('*')
             if p.is_file() and '__pycache__' not in p.parts]
    files += [root / name for name in ('pyproject.toml', 'uv.lock', 'README.md', 'docker-compose.yml')]
    archive = destination / 'pre-v3-checkout.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as output:
        for path in sorted(files):
            output.write(path, path.relative_to(root).as_posix())
    index = {}
    for folder in ('datasets', 'runs', 'experiments'):
        for path in sorted((root / folder).rglob('*')):
            if path.is_file() and destination not in path.parents:
                index[path.relative_to(root).as_posix()] = hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
    atomic_json(destination / 'old-artifact-index.json', index)
    scenarios = [
        ('healthy', []), ('catalogue_db_stop', [['resource/catalogue-db', 'container_stopped']]),
        ('orders_stop', [['resource/orders', 'container_stopped']]),
        ('payment_cpu', [['resource/payment', 'cpu_contention']]),
        ('orders_payment_delay', [['edge/orders/payment', 'dependency_latency']]),
        ('carts_memory', [['resource/carts', 'memory_pressure']]),
        ('payment_stop', [['resource/payment', 'container_stopped']]),
        ('orders_db_stop', [['resource/orders-db', 'container_stopped']]),
        ('user_stop', [['resource/user', 'container_stopped']]),
        ('shipping_stop', [['resource/shipping', 'container_stopped']]),
        ('catalogue_db_payment_cpu', [['resource/catalogue-db', 'container_stopped'], ['resource/payment', 'cpu_contention']]),
    ]
    value = {
        'schema_version': 3, 'task_id': 'sockshop_multicause_v3',
        'scenarios': [{'stratum': name, 'components': components} for name, components in scenarios],
        'hypotheses': sorted({tuple(sorted(cause for cause, _ in components)) for _, components in scenarios}),
        'episode': {'budget': 10, 'max_probes': 5, 'window_seconds': 120},
        'objective': {'lambda_cost': .05, 'correct': 1., 'incorrect': 0., 'defer': .25},
        'collection': {'sessions': {'train': 20, 'validation': 10, 'test': 10}, 'order_seed': 11,
                       'baseline_seconds': 120, 'settling_seconds': 30, 'ingestion_seconds': 10,
                       'pilots_per_new_scenario': 5, 'entry_protocol': 'manual_frontend'},
        'training': {'seeds': [11, 22, 33, 44, 55], 'episodes': 10000, 'validation_interval': 500,
                     'epsilon_start': .2, 'epsilon_end': .05, 'epsilon_decay_episodes': 8000,
                     'selection': ['validation_mean_return', 'lower_mean_credits'],
                     'prior': 'balanced_hypotheses', 'payment_mechanism_mix': [.5, .5]},
        'methods': ['expected-sarsa', 'two-step-sarsa', 'voi', 'bounded-dp', 'dqn'],
        'dqn': {'hidden': [128, 128], 'optimizer': 'Adam', 'learning_rate': .001, 'gamma': 1.,
                'loss': 'Huber', 'replay_capacity': 50000, 'batch_size': 64, 'warmup': 1000,
                'updates_per_transition': 1, 'target_sync_updates': 1000, 'gradient_norm_cap': 10,
                'device': 'cpu', 'threads': 1, 'variant': 'vanilla'},
        'baseline_search': {'orders': 32, 'confidence_thresholds': [.6, .75, .9, .95, .99]},
        'planner': {'depth': 2, 'max_expanded_states': 50000},
        'diagnostic_gate': {'overall': .9, 'each_stratum': .9, 'healthy_specificity': .9},
        'promotion': {'overall': .9, 'pair': .9, 'healthy_specificity': .9,
                      'return_advantage': .02, 'paired_session_interval_lower_bound': 0.,
                      'bootstrap_seed': 11, 'bootstrap_samples': 10000, 'confidence_level': .95,
                      'compute_noninferiority_margin': .02, 'report_all_seeds': True},
        'metrics': ['exact_set_accuracy', 'pair_accuracy', 'missing_second_root', 'extra_root',
                    'root_precision', 'root_recall', 'root_f1', 'jaccard', 'healthy_specificity',
                    'defer_rate', 'diagnosis_coverage', 'return', 'credits', 'probes',
                    'decision_mean_median_p95_seconds', 'training_seconds', 'peak_ram', 'calibration'],
        'provenance': {'git_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
                       'pre_v3_runtime_hash': runtime_hash(),
                       'snapshot_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                       'old_artifact_index_hash': digest(index),
                       'lock_sha256': hashlib.sha256((root / 'uv.lock').read_bytes()).hexdigest(),
                       'registry_sha256': hashlib.sha256((root / 'configs/resources_sockshop_v2.yaml').read_bytes()).hexdigest(),
                       'helper_sha256': hashlib.sha256((root / 'lab/adaptive-helper/rca-helper-lease').read_bytes()).hexdigest(),
                       'docker_image_ids': None, 'live_inventory_status': 'blocked_docker_engine_unavailable'},
    }
    value['hash'] = digest(value)
    atomic_json(declaration_path, value)
    atomic_json(root / 'runs/adaptive_v3_multi/phase-status.json', {
        'schema_version': 3, 'declaration_hash': value['hash'], 'completed_phases': [],
        'phase_0': 'offline_definition_frozen_live_inventory_pending', 'process_owner': None,
        'log_paths': [], 'accepted_slots': {}, 'pause_state': False,
        'blockers': ['Docker Desktop Linux engine unavailable'],
    })
    print(json.dumps({'declaration_hash': value['hash'], 'old_artifacts': len(index), 'snapshot': str(archive)}))


if __name__ == '__main__':
    main()
